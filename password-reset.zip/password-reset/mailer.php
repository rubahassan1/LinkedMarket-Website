<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

//require __DIR__ . '/../phpmailer/src/Exception.php';
//require __DIR__ . '/../phpmailer/src/PHPMailer.php';
//require __DIR__ . '/../phpmailer/src/SMTP.php';

require __DIR__ . "/../vendor/autoload.php";

$mail = new PHPMailer(true);

//$mail -> SMTP::DEBUG_SERVER;

$mail->isSMTP();
$mail->SMTPAuth = true;
$mail->Host = "smtp.gmail.com";
$mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
$mail->Port = 587;
$mail->Username = "22130312@students.liu.edu.lb";
$mail->Password = "0312Rubah1";
$mail->isHTML(true);

// Don't include "return $mail;" here
return $mail;