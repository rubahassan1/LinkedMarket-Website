<?php

include "../config.php";

$email = $_POST['email'];
$token = bin2hex(random_bytes(16));
$token_hash = hash("sha256", $token);
$expiry = date("Y-m-d H:i:s", time() + 60 * 30);

$sql = "UPDATE user SET reset_token_hash=?, reset_token_expires_at=? WHERE Email=?";
$stmt = mysqli_prepare($con, $sql);
mysqli_stmt_bind_param($stmt, "sss", $token_hash, $expiry, $email);
mysqli_stmt_execute($stmt);

if(mysqli_stmt_affected_rows($stmt)){
    require __DIR__ . '/mailer.php';

    $mail->setFrom("noreply@example.com");
    $mail->addAddress($email);
    $mail->Subject = "Password Reset";
    $mail->isHTML(true); // Ensure HTML format
    $resetLink = "http://localhost/linkm8/password-reset/reset-password.php?token=$token";
    $mail->Body = "Click <a href=\"$resetLink\">here</a> to reset your password"; // Using variable for link
    $mail->AltBody = "Click the following link to reset your password: $resetLink"; // Plain text alternative

    try {
        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer error: {$mail->ErrorInfo}";
    }
}
